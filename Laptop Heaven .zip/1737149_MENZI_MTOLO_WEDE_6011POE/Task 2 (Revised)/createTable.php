<?php 

$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname="test";


//create connection 
$connect= mysqli_connect ($servername, $username, $password ,$dbname);
if (!$connect)
{
die ('Could not connect:' . mysql_error());
}
//mysql_select_db($dbname,$connect);


//Code to see if Table Exists
$exists = mysqli_query($connect,'select 1 from user');

if($exists !== FALSE)
{
   echo("This table exists");
}else{
   echo("This table doesn't exist");
}
// Create connection
	$conn = mysqli_connect($servername, $username,$password,$dbname);
 

 // Check connection
 
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
 
 


	$conn->close();

//search dropping a table php 


//create table php 



//load data using source file or text file 

?>
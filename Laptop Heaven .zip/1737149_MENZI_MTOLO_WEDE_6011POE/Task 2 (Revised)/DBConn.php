<!DOCTYPE HTML>
<html>
<head>
<title> Connection1</title>
</head>

<body>
<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname="test";

// Create connection
	$conn = mysqli_connect($servername, $username,$password,$dbname);
 

 // Check connection
 
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
 
 


	$conn->close();
 ?> 
</body>
</html>




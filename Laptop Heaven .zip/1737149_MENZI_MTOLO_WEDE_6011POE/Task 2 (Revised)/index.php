<?php
	session_start();
	
	// connect to database
	$dbname = mysqli_connect("localhost","root","","test");
	
	if(isset($_POST['submit']))
	{
	$username = mysqli_real_escape_string($_POST['username']);
	$email = mysqli_real_escape_string($_POST['email']);
	$password = mysqli_real_escape_string($_POST['password']);
	$password2 = mysqli_real_escape_string($_POST['password2']);
	
	if(password == password2)
	{
	//create
	$password = md5 ($password); //hash password before storing for security purposes
	$sql = "INSERT INTO users(username,email,password) VALUES('$username' , '$email' , '$password' )";
	mysqli_query($dbname, $sql);
	$_SESSION['message'] = "You are now logged in";
	$_SESSION[''] = $username;
	header("location: home.php"); //redirect to home page 
	
	}
	else
		{
			$_SESSION['message'] = "The two passwords do not match ";
		}
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>  Login  </title>
		
		
		
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	
	
	<body style = 'background-color:  aqua'>
	

			<div class = "header">


				
			</div>
							<center><h1>LOGIN</h1></center>
			<center>
			<form method="post" action="items.php">
				<table>
					<tr>
						<td>Name:</td>
						<td><input type="text" name="username" class="textInput"></td>
							
					</tr>
					
					<tr>
						<td>Surname:</td>
						<td><input type="text" name="username" class="textInput"></td>
							
					</tr>
					
					<tr>
						<td>Email:</td>
						<td><input type="email" name="email" class="textInput"></td>
							
					</tr>
					
					<tr>
						<td>Password:</td>
						<td><input type="password" name="password" class="textInput"></td>
							
					</tr>
			</center>
					
					
					<tr>
						<td></td>
						<td><input type="submit" name="submit" class="textInput"></td>
							<div><a href="register.php?register=1">Create a new account?</a></div>
					</tr>
				</table>	
			</form>
	</body>
</html>
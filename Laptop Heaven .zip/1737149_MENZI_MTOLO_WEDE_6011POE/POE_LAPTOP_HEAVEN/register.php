<?php
	session_start();
	
	// connect to database
	$dbname = mysqli_connect("localhost","root","","test");
	
	if(isset($_POST['register_btn']))
	{
	$username = mysql_real_escape_string($_POST['username']);
	$email = mysql_real_escape_string($_POST['email']);
	$password = mysql_real_escape_string($_POST['password']);
	$password2 = mysql_real_escape_string($_POST['password2']);
	
	if(password == password2)
	{
	//create
	$password = md5 ($password); //hash password before storing for security purposes
	$sql = "INSERT INTO users(username,email,password) VALUES('$username' , '$email' , '$password' )";
	mysqli_query($dbname, $sql);
	$_SESSION['message'] = "You are now logged in";
	$_SESSION[''] = $username;
	header("location: home.php"); //redirect to home page 
	
	}
	else
		{
			$_SESSION['message'] = "The two passwords do not match ";
		}
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>  Login  </title>
		
		
		
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	
	
	<body style = 'background-color: #808080'>
	

			<div class = "header">
				<h1>Register</h1>
			</div>
			
			<form method="post" action="indexa.php">
				<table>
					<tr>
						<td>Name:</td>
						<td><input type="text" name="username" class="textInput"></td>
							
					</tr>
					
					<tr>
						<td>Surname:</td>
						<td><input type="text" name="username" class="textInput"></td>
							
					</tr>
					
					<tr>
						<td>Email:</td>
						<td><input type="email" name="email" class="textInput"></td>
							
					</tr>
					
					<tr>
						<td>Password:</td>
						<td><input type="password" name="password" class="textInput"></td>
							
					</tr>
					
					
					
					<tr>
						<td></td>
						<td><input type="submit" name="register_btn" class="textInput"></td>
							
					</tr>
				</table>	
			</form>
	</body>
</html>
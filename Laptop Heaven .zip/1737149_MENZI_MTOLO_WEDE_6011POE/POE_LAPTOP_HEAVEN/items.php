<!DOCTYPE html>
<html>

<head>

    <title>'Home Page'</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="css/login.css"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>

<body>
    <div id="login">
   <center>     <h1>Successfully Signed-in</h1> </center>
		
<center><p><h2>ITEMS</h2></p></center>
<center>
<form action="/action_page.php">
  <select name="watch" size="15" multiple>
	 <option value="HP Notepad X">|| No. || Description || Cost price || Quantity || Sell Price </option>
    <option value="HP Notepad X">HP Notepad X</option>
    <option value="Dell Latitude">Dell Latitude</option>
    <option value="Mecer Expression Z">Mecer Expression Z</option>
    <option value="Deepsea Dive D Blue">Apple Macbook Pro</option>
	<option value="Asus ROG">Asus ROG</option>
    <option value="Dell XPS">Dell XPS</option>
    <option value="Acer Predator">Acer Predator</option>
    <option value="Samsung Notepad<">Samsung Notepad</option>
	<option value="Ice out">Lenovo Yoga</option>
    <option value="Joop Men">Surface Pro Book</option>
    <option value="Kenneth Cole New York"> Huawei MateBook X Pro </option>
    <option value="Megir Luxury Mens Leather">Razer</option>
	<option value=" MICHAEL KORS PARKER">ThinkPad T series </option>
    <option value="Neil leather">Google Notepad Z series </option>
    <option value="Rolex">HP Notepad</option>
    <option value="Swiss Military Hanowa">Swiss Military Hanowa</option>
  </select>
  <br><br>
  <input type="submit">
</form>
</center>

<p></p>

</body>
</html>


